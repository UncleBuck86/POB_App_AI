export const vendors = [
  { key: "PHI", label: "PHI" },
  { key: "Bristow", label: "Bristow" },
  { key: "RLC", label: "RLC" },
  { key: "Era", label: "Era" },
  { key: "Custom", label: "Custom" },
] as const;
